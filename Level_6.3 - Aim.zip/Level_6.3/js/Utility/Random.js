function rand(low, high)
{
		return Math.random() * (high - low) + low;
}