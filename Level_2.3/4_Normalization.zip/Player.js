// JavaScript Document
function Player()
{
	this.x = canvas.width/2;
	this.y = canvas.height/2;
	this.scaleX = 1;
	this.scaleY = 1;
	this.width = 100;
	this.height = 100;
	this.rotation = 0;
	this.spd = 2;
	this.vx = 0;
	this.vy = 0;
	this.ax = 1;
	this.ay = 1;
	this.color = "#ff0000";
	
	this.top = function()
	{
		return{
			x:this.x,
			y:this.y - this.height/2
		}
	}
	this.right={}
	this.bottom = {}
	this.left = {}
	
	
	this.draw = function()
	{
		context.save();
			context.fillStyle = this.color;
			context.translate(this.x, this.y);
			context.fillRect((-this.width/2), (-this.height/2), this.width, this.height);
		context.restore();
		
	}	
}
