// JavaScript Document


//------------Bounding Box Collision--------------------------------------
function overlap(object1, object2)
{
	if(
	  object1.y - object1.height/2 < object.y + object.height/2 &&
	   object1.x + object1.width/2 > object.x - object.width/2 && 
	   object1.y + object1.height/2 > object.y - object.height/2 && 
	   object1.x - object1.width/2 < object.x + object.width/2 )
	   
	{
		return true;
	}
	else
	{
		return false;
	}

}
//------------------------------------------------------------------------