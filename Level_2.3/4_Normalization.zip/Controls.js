// JavaScript Document

//You can find Keycodes here http://keycode.info/  and here https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/keyCode
var w = false;
var a = false;
var s = false;
var d = false;

document.addEventListener("keydown", keydown, false);

function keydown(e)
{
	//-----------UnComment to check keycodes in the Browser's console--------------
	//console.log(e.keyCode);
	if(e.keyCode == 68)
	{
		d = true;	
	}
	if(e.keyCode == 65)
	{
		a = true;	
	}
}

document.addEventListener("keyup", keyup, false);

function keyup(e)
{
	if(e.keyCode == 68)
	{
		d = false;	
	}
	if(e.keyCode == 65)
	{
		a = false;	
	}
}