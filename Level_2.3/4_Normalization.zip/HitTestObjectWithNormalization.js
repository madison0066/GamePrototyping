// JavaScript Document

var canvas;
var context;
var timer;
var interval = 1000/60;
var player;
var directionX = 1;;

//---------------Set Friction---------------------------------------------------
var object;
//------------------------------------------------------------------------------


var frictionX = .85;	

window.onload = function()
{
	canvas = document.getElementById("canvas");
	context = canvas.getContext("2d");	
	player = new Player();
	
	//--------------Instantiate new Object using the Player Class--------------
	object = new Player();
	object.color = "#ff00ff";
	//-------------------------------------------------------------------------
	
	timer = setInterval("animate()", interval);
}

function animate()
{
	context.clearRect(0,0,canvas.width, canvas.height);	
	
	
	if(d)
	{	
		player.vx += player.ax * player.spd;
	}
	if(a)
	{
		player.vx += -player.ax * player.spd;
	}
	
	//---------Normalize the velocity to create a modifier that affects the direction the player is moving in--------------
	if(Math.abs(player.vx) > 0)
	{
		directionX = player.vx/Math.abs(player.vx);	
		console.log(directionX);	
	}
	//----------------------------------------------------------------------
	player.vx *= frictionX;
	player.x += player.vx;
	
	//--------------Check for Collision--------------------------------------
	while(overlap(player, object))
	{
		player.x -= directionX;
	}
	//-----------------------------------------------------------------------
	
	//---------------Draw both objects---------------------------------------
	object.draw();
	player.draw();
	//-----------------------------------------------------------------------
}

